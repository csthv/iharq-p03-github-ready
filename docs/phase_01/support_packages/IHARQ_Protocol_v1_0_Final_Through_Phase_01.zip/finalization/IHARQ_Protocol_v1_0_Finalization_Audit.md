# IHARQ Protocol v1.0 Through Phase 1 — Final Independent Finalization Audit

**Audit ID:** `IHARQ-PROTOCOL-V1-FINALIZATION-AUDIT-P01-R1`  
**Generated:** `2026-08-08T01:03:13+03:30`  
**Canonical authority:** `IHARQ-PROTOCOL-V1-CUMULATIVE-THROUGH-P01-R1`  
**Canonical Markdown SHA-256:** `0f4048e39ff1447e9e60d45c4f1e3b345fb3ac369abafb4f32db4ebd0ca655a3`  
**Decision:** **PROTOCOL_V1_FINALIZATION_THROUGH_P01: PASS — FINALIZED AND FROZEN**

## 1. Executive decision

The independent finalization audit supports **Case A**: the current R1 canonical Protocol is semantically correct. No canonical semantic repair, rewrite, ID change, or revision bump is justified. The canonical Markdown is therefore retained byte-for-byte unchanged. The DOCX derivative is also retained unchanged after a fresh 76-page render and visual inspection.

A potential high-risk issue—the core external Dataset's logical immutable revision `1` versus Kaggle provider Dataset version `2`—was independently investigated. The accepted adoption record explicitly distinguishes these two semantics. Provider version 1 is historical shell lineage; provider version 2 is the verified scientific artifact, while the governed logical immutable revision remains 1. The current R1 already records `provider v2 / logical rev1`, so no defect exists.

## 2. Final status table

| Validation surface | Final status |
| --- | --- |
| Single canonical Protocol | PASS |
| Canonical ID | IHARQ-PROTOCOL-V1-CUMULATIVE-THROUGH-P01-R1 |
| Canonical revision retained/changed | RETAINED |
| P00 preservation | PASS |
| P01 integration | PASS |
| Governance V6.1 | PASS |
| Seven-authority conformance | PASS |
| Build Book intent fidelity | PASS |
| P01 execution fidelity | PASS |
| Inter-level harmony | PASS |
| Intra-level harmony | PASS |
| Cross-phase harmony | PASS |
| Dataset identities | PASS |
| Labels/exclusions | PASS |
| Split/leakage | PASS |
| Calibration budgets | PASS |
| Preprocessing | PASS |
| Core window | PASS |
| Core Dataset pointer | PASS |
| A0–A13 | PASS |
| A14 absence | PASS |
| A4 R2 synchronization | PASS |
| A4 executed_in_p01=false boundary | PASS |
| Environment | PASS |
| Adaptive-disk amendment | PASS |
| Repair/rerun history | PASS |
| R54 security repair | PASS |
| P01 stages 00–26 | PASS |
| P01 gates | PASS |
| Tests | PASS |
| Negative/failed evidence | PASS |
| External artifacts | PASS |
| P01→P02 handoff | PASS |
| Structured YAML/JSON parse | PASS |
| Human/structured no-drift | PASS |
| DOCX critical parity | PASS |
| DOCX visual QA | PASS — 76/76 pages |
| Protocol package CRC | PASS |
| P01 execution bundle CRC | PASS |
| P01 checksums | PASS — 13,164/13,164 |
| Secrets | PASS — 0 credential-value hits |
| Placeholders | PASS — 0 unresolved freeze-critical hits |
| Unsafe paths | PASS |
| Freeze-critical blockers | 0 |

## 3. Canonical authority and revision disposition

- **Canonical Protocol authority:** `IHARQ_Experiment_Ablation_Evaluation_Protocol_v1_0_Current.md`.
- **Authority representation:** `SINGLE_CANONICAL_DOCUMENT`.
- **Canonical Protocol ID:** `IHARQ-PROTOCOL-V1-CUMULATIVE-THROUGH-P01-R1`.
- **Revision:** **RETAINED**.
- **Semantic canonical changes during finalization:** **NONE**.
- **DOCX status:** non-authoritative format-equivalent derivative; no semantic or layout repair required in this final pass.
- JSON/audit/checksum artifacts in the final package are support/validation derivatives only.

## 4. P00 preservation

The direct `IHARQ-PROTOCOL-V1-P00-ANNEX-R2` source was independently rehashed as `a0dbabfc1c5be739955696f8b5d32d9cdbdedf563a1c9225d9767599bbfbd7b5` and is present verbatim inside the cumulative Protocol. The direct P00 run matrix contains 19 engineering cells and its source SHA-256 reconciles with the embedded structured source identity. The direct P00 analysis contract contains 6 allowed analyses and is embedded as an exact structured predecessor object. Historical Mode-B / `ENGINEERING_FOUNDATION_CONFORMANCE` remains historical evidence classification and does not override Governance V6.1.

## 5. P01 intended-versus-actual fidelity

The pre-run Build Book freeze and accepted execution were independently compared. The Protocol correctly preserves both when they differ.

| Surface | Pre-run intent | Accepted execution / controlling observed state | Finalization finding |
| --- | --- | --- | --- |
| Scientific freeze | `P01-L1-OFFICIAL-RUN-FREEZE-R2` | same | PASS |
| Active datasets | PhysioNetMI; BNCI2014_001; Lee2019_MI | same; Cho2017/GuttmannFlury not admitted | PASS |
| Split | subject-grouped, SHA-256 deterministic, seed 20260804 | accepted SplitRecord matches | PASS |
| Budgets | 1/2/4/8/16/32 per class from calibration | infrastructure registered; no P01 budget-effectiveness claim | PASS |
| Core window | cue +0.5..+3.5 s; 480 @160 Hz; reject OOB; no clipping | 12,910 windows; 0 invalid; 172 shards | PASS |
| Environment | Python >=3.11,<3.12; 60 GiB historical minimum | Python 3.12.13; adaptive 6.0 GiB effective floor; pins/imports PASS | PASS — amendment explicit |

## 6. Dataset, label, split, preprocessing, and core checks

- **datasets: PASS** — Three active DatasetRecords; screened sources remain inactive.
- **dataset_record_ids: PASS** — All three DatasetRecord IDs and semantic hashes present in canonical narrative.
- **labels: PASS** — LabelMapRecords and normalized binary labels reconcile.
- **split: PASS** — SplitRecord agrees with Build Book subject-grouped deterministic freeze.
- **budgets: PASS** — Registered low-calibration budget infrastructure retained without P01 experiment claim.
- **preprocessing: PASS** — Accepted PreprocessingRecord matches Build Book freeze-critical sequence.
- **core_window: PASS** — Build Book core window and accepted persisted pointer/counts reconcile.
- **core_external_dataset: PASS** — Provider v2 / logical rev1 distinction independently reconciled from adoption record.
- **quality: PASS** — Quality freeze preserved.

The accepted core Dataset pointer was independently reconciled to `provider_dataset_version=2`, `logical_immutable_revision=1`, 12,910 windows, 172 shards, float32, and manifest SHA-256 `dc21f418e9a1add62adb346f627d5d729735a5cfede627e1`.

## 7. A0–A13, A14, and A4

- **A0–A13:** exactly 14 authoritative global identities are present in the structured cumulative register.
- **A14:** `PROHIBITED_ABSENT`; no selector, run, result, or claim.
- **A4 R2:** `A4_LONG_MATCHED_3P5S_R2` = +0.0..+3.5 s, 560 samples @160 Hz; multi-view profile `A4_MULTI_3X2S_UNIFORM_0P75S_R2` = slices 0:320, 120:440, 240:560; 12,910/12,910 matched parents; no clipping/padding/fabrication/drop.
- The canonical Protocol explicitly states that R2 followed feasibility evidence, is **not described as preregistered**, and `executed_in_p01 = false`. It is synchronized for future downstream confirmatory use only.

## 8. Execution chronology, repair lineage, gates, and tests

- Accepted execution stage identity: **00–26 exactly once; 27/27 final PASS**.
- Gates: **P01-G01..P01-G16 = 16/16 PASS**.
- Test manifest: **50 passed**, return code 0.
- Final unresolved blockers: **0**.
- Material R45–R54 repair lineage remains visible. Stage-07 guard, Stage-18 integration, and Stage-26/R54 security/repackaging history are not erased or upgraded into prospective intent.
- R54 remains classified as packaging/security-only; scientific change = false; contaminated failed release is non-authoritative.

## 9. Integrity rechecks

### Current R1 Protocol package
- SHA-256: `07e433c28fa83fcf7962f39734e0c55ac3140b9708f1db2321466270d450f114`
- ZIP members: **9**
- ZIP CRC: **PASS**
- checksum rows: **8**
- missing: **0**
- mismatches: **0**
- unsafe paths: **0**

### Final P01 execution bundle
- SHA-256: `09c3bb0442d79ddf110cf66fc4fe61fe63e94c7d8ed9f198f606639b4191f16e`
- ZIP members: **13216**
- ZIP CRC: **PASS**
- checksum rows independently rehashed: **13164**
- missing: **0**
- mismatches: **0**
- unsafe paths: **0**

## 10. DOCX derivative audit

- DOCX SHA-256: `bbb7e2488658cb81f70bbdf170d7420453524b24fa07cc287466fd723a42661a`.
- Fresh render: **76 pages**.
- Visual review: **76/76 pages**.
- Blank/orphan pages: 0.
- Clipping/overlap/broken tables: 0 observed.
- Critical canonical IDs/statuses present in DOCX XML: PASS.
- Credential-value pattern scan: 0.
- Freeze-critical placeholder scan: 0.

## 11. Content-preservation matrix

| Predecessor source | Predecessor section/rule | Current location | Preservation status | Semantic change? | Reason |
| --- | --- | --- | --- | --- | --- |
| P00 Annex R2 | entire direct annex text | Part II | PRESERVED_EXACT | NO | Byte-for-byte source text is embedded; historical Mode-B remains historical. |
| P00 run_matrix.yaml | 19 engineering cells | Part IV / Appendix B | PRESERVED_SEMANTICALLY | NO | All 19 cells preserved with source hash and phase identity. |
| P00 analysis_contract.yaml | 6 allowed analyses + rules | Part V / Appendix C | PRESERVED_EXACT | NO | Exact predecessor object embedded. |
| Master R3 predecessor | current project-wide rules | Part I | MOVED_WITHOUT_CHANGE | NO | Substantive current rules internalized; predecessor identity retained in supersession history. |
| P01 Annex R1 predecessor | P01 execution-and-analysis contract | Part III | MOVED_WITHOUT_CHANGE | NO | Integrated into canonical cumulative authority. |
| P01 run matrix | 27 accepted stages | Part IV / Appendix B | PRESERVED_SEMANTICALLY | NO | Final accepted stage identities 00–26 exactly once. |
| P01 analysis contract | 10 P01 data-foundation analyses | Part V / Appendix C | PRESERVED_SEMANTICALLY | NO | No inferential statistics invented. |
| A4 R1 history | failed 4.0 s alternative proposal | Part III / Part VI / Part VII | PRESERVED_SEMANTICALLY | NO | Historical failed proposal retained; not represented as preregistered R2. |
| R45–R54 repair lineage | material repair history | Part VII | PRESERVED_SEMANTICALLY | NO | Material episodes retained; transient retry noise consolidated. |
| Separate former Protocol companion files | distribution architecture | supersession metadata | REMOVED_AS_OBSOLETE_WITH_SUPERSESSION | NO | Substantive content embedded; separate files no longer competing authorities. |

## 12. Ten-pass finalization suite

| Pass | Status | Independent finding |
| --- | --- | --- |
| PASS 1 — Structural completeness | PASS | All required canonical parts I–XI and appendices A–I exist; one current authority only. |
| PASS 2 — Source authority | PASS | Freeze-critical values routed to lawful Governance/Architecture/Registry/Plan/Protocol/Playbook/Method/N&B/Build Book/execution owners. |
| PASS 3 — P00 preservation | PASS | Direct Annex R2 embedded verbatim; P00 19-cell run matrix and 6-analysis contract preserved. |
| PASS 4 — P01 execution fidelity | PASS | Accepted bundle controls actual state: P01/L1, 27 stages, 16 gates, 50 tests, 0 blockers. |
| PASS 5 — Inter-level harmony | PASS | No unresolved ownership/identity conflict across the authority stack. |
| PASS 6 — Intra-level harmony | PASS | Narrative, cumulative registers, structured appendices, status and handoff surfaces reconcile. |
| PASS 7 — Cross-phase harmony | PASS | P01 extends P00; historical P00 workflow state remains history; V6.1 controls current procedure. |
| PASS 8 — No-post-hoc and repair chronology | PASS | Intent, failed attempts, repairs, reruns, final acceptance and future confirmatory A4 contract remain separated. |
| PASS 9 — A0–A13 / A4 / A14 | PASS | A0–A13 complete; A14 absent/prohibited; A4 R2 synchronized for future use and not claimed executed in P01. |
| PASS 10 — Human/structured/downstream usability | PASS | Six embedded YAML blocks parse; zero freeze-critical drift; Phase Report and P02 can consume identities/contracts directly. |

## 13. Adversarial review

The Protocol was read as a thesis examiner, reproducibility reviewer, future P02 engineer, and evidence-governance auditor. No contradictory canonical ID, hidden material failure, unstated scientific amendment, denominator drift, A14 leakage, falsely preregistered A4 wording, environment-history drift, broken external pointer, unsupported PASS assertion, or downstream-ownership overreach was found. The provider-version/logical-revision question was resolved from the actual adoption record and does not constitute a defect.

## 14. Final certification

```text
PROTOCOL_V1_FINALIZATION_THROUGH_P01:
PASS — FINALIZED AND FROZEN

canonical_protocol_id: IHARQ-PROTOCOL-V1-CUMULATIVE-THROUGH-P01-R1
canonical_revision: RETAINED
P00_status: PRESERVED
P01_status: INCORPORATED_AND_FROZEN
A0_A13: COMPLETE
A14: ABSENT_PROHIBITED
A4_R2: PROTOCOL_SYNCHRONIZED_FOR_FUTURE_DOWNSTREAM_USE
P01_additional_computation_required: NO
freeze_critical_blockers: 0
ready_for_phase_1_evidence_results_interpretation_report: YES

Phase 1 execution: ACCEPTED
Protocol v1.0 through P01: FINALIZED
Next governed step: Phase 1 Evidence, Results, and Interpretation Report
```

This certification does **not** claim that the entire Phase 1 governance lifecycle is closed. Protocol finalization is the controlling input to the remaining documentary closure chain.

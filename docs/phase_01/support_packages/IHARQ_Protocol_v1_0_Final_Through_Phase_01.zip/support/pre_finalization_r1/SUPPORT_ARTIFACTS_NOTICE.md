# Support-artifact authority notice

The **only current authoritative Protocol v1.0 source** in this package is:

`IHARQ_Experiment_Ablation_Evaluation_Protocol_v1_0_Current.md`

Canonical Protocol identity: `IHARQ-PROTOCOL-V1-CUMULATIVE-THROUGH-P01-R1`.

`IHARQ_Experiment_Ablation_Evaluation_Protocol_v1_0_Current.docx` is a **format-equivalent, non-authoritative Word derivative** generated from the same canonical Markdown for human review, thesis use, and transport.

All other files in this package are **non-authoritative validation/support artifacts**. They may verify, explain, or checksum the canonical Protocol, but they do not define an alternative Protocol truth.

The owner-directed transition from separate master/phase/run/analysis Protocol surfaces to this single cumulative Protocol representation is a document-structure consolidation only. It changes no scientific contract, historical execution, phase identity, ablation identity, denominator, or evidence ceiling.

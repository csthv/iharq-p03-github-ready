# IHARQ Protocol v1.0 — Single Canonical Through P01 Final Validation Report

**Protocol authority:** `SINGLE_CANONICAL_DOCUMENT`  
**Canonical Protocol ID:** `IHARQ-PROTOCOL-V1-CUMULATIVE-THROUGH-P01-R1`  
**Phases represented:** `P00, P01`  
**Final decision:** `PROTOCOL_V1_SINGLE_CANONICAL_THROUGH_P01: PASS — FROZEN`

## Final validation summary

| Validation surface | Final status |
|---|---|
| Exactly one current authoritative Protocol v1.0 document | PASS |
| P00 direct Protocol v1.0 source preservation | PASS |
| P01 integration | PASS |
| Project-wide authority preservation | PASS |
| Governance V6.1 conformance | PASS |
| Seven-authority conformance | PASS |
| Build Book intent vs actual execution separation | PASS |
| Phase 0 execution/history fidelity | PASS |
| Phase 1 accepted execution fidelity | PASS |
| Inter-level harmony | PASS |
| Intra-level harmony | PASS |
| Cross-phase harmony | PASS |
| Dataset / label / exclusion identities | PASS |
| Split and leakage contract | PASS |
| Preprocessing contract | PASS |
| Official core-window contract | PASS |
| Core external Dataset identity | PASS |
| A0–A13 cumulative register | PASS |
| A14 prohibition / absence | PASS |
| A4 R2 synchronization | PASS |
| A4 `executed_in_p01=false` evidence ceiling | PASS |
| Actual Python/environment amendment | PASS |
| Adaptive-disk/resource amendment | PASS |
| Material failed attempts preserved | PASS |
| Material repair/rerun history preserved | PASS |
| Stage-26/R54 security repair preserved | PASS |
| Cumulative run matrix | PASS |
| Cumulative analysis contract | PASS |
| Cumulative limitation register | PASS |
| Cumulative external-artifact register | PASS |
| Embedded structured YAML parseability | PASS |
| Human/structured freeze-critical no-drift | PASS |
| Final P01 execution ZIP CRC | PASS |
| Final P01 execution-bundle checksum rows | PASS — 13,164/13,164 |
| Current Protocol placeholder scan | PASS — 0 hits |
| Current Protocol secret scan | PASS — 0 hits |
| DOCX OOXML secret scan | PASS — 0 hits |
| DOCX OOXML unresolved-placeholder scan | PASS — 0 hits |
| DOCX critical-ID/content parity | PASS |
| DOCX visual render QA | PASS — 76/76 pages |
| Freeze-critical blockers | **0** |

## Ten-pass final double-check

1. **Completeness — PASS.** All valid project-wide, P00 and P01 Protocol-bearing material required by the consolidation prompt is represented inside one cumulative authority, with structured run, analysis, ablation, external-artifact, source-utilization and integrity appendices.
2. **Source authority — PASS.** Freeze-critical values were routed to their lawful owners: Governance, Architecture, Registry, Execution and Evidence Plan, Protocol v0.1, Playbook, Method Selection, Nuts-and-Bolts, Implementation Build Book, direct Phase 0 Protocol v1.0 sources, and final execution evidence.
3. **Phase 0 preservation — PASS.** The direct P00 Annex R2 source is preserved exactly; its SHA-256 is `a0dbabfc1c5be739955696f8b5d32d9cdbdedf563a1c9225d9767599bbfbd7b5`. Historical Mode-B engineering/retrospective classification remains historical evidence and is not upgraded.
4. **Phase 1 execution fidelity — PASS.** The accepted 00–26 execution, 12,910 core windows, 0 invalid windows, 172 core shards, P01-G01..G16 closure, A4 R2 foundation, runtime amendments, and R54 repair are faithfully represented.
5. **Inter-level harmony — PASS.** No current Protocol rule steals or contradicts an upstream/downstream owner's authority.
6. **Intra-level harmony — PASS.** Repeated identifiers resolve consistently; current and historical values are explicitly distinguished.
7. **Chronology/no-post-hoc integrity — PASS.** Pre-run intent, initial execution, failed attempts, repairs, final accepted execution and future confirmatory contracts remain separated. A4 R2 is not falsely described as prospectively preregistered or as P01 effectiveness evidence.
8. **Ablation integrity — PASS.** A0–A13 are represented; A14 is prohibition/absence only; A4 R2 identities and denominator are synchronized without padding, clipping, fabrication or silent event loss.
9. **Human/structured no-drift — PASS.** Embedded YAML blocks parse and reconcile to the narrative for all freeze-critical identities/statuses.
10. **Downstream usability — PASS.** The Phase 1 Report, Layer 0, Evidence Map, Layer 10 and P02 can consume stable identities/contracts without consulting a competing Protocol authority.

## Independent execution-integrity recheck

The final P01 execution bundle was independently reopened and reverified during consolidation:
- ZIP CRC: PASS
- members: 13,216
- `checksums.sha256` rows: 13,164
- missing checksum targets: 0
- checksum mismatches: 0
- unsafe ZIP paths: 0

## Word shipping gate

The DOCX was rendered after the last layout correction and visually reviewed through all **76 pages**. The earlier orphan separator/blank-page defect was repaired before this final render. Final visual status:
- blank pages: 0
- clipped text/tables: 0
- detected overlap: 0
- broken headers/footers: 0
- visibly truncated structured blocks: 0

## Authority and forward rule

Only the canonical Markdown is the current Protocol authority. The DOCX is a non-authoritative format derivative; validation artifacts are support only.

Future phases must extend the **same cumulative canonical Protocol v1.0 document**. Separate phase Protocol files may be archived as predecessor evidence but must not become competing current authorities.

# Final certification

**PROTOCOL_V1_SINGLE_CANONICAL_THROUGH_P01: PASS — FROZEN**

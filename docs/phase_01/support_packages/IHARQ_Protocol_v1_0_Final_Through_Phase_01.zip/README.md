# IHARQ Protocol v1.0 Final Through Phase 01

## Canonical authority

**CANONICAL PROTOCOL AUTHORITY:** `IHARQ_Experiment_Ablation_Evaluation_Protocol_v1_0_Current.md`

- Canonical ID: `IHARQ-PROTOCOL-V1-CUMULATIVE-THROUGH-P01-R1`
- Canonical revision: **RETAINED**
- Canonical Markdown SHA-256: `0f4048e39ff1447e9e60d45c4f1e3b345fb3ac369abafb4f32db4ebd0ca655a3`
- Finalization decision: **PROTOCOL_V1_FINALIZATION_THROUGH_P01: PASS — FINALIZED AND FROZEN**

## Derivative/support status

- `IHARQ_Experiment_Ablation_Evaluation_Protocol_v1_0_Current.docx`: non-authoritative format-equivalent derivative.
- `finalization/*.md|json`: non-authoritative independent audit/support records.
- `support/`: pre-finalization R1 audit/support material retained for provenance only.
- `IHARQ_Protocol_v1_0_Current_Consolidation_Supersession_Manifest.json`: non-authoritative structural provenance.
- `checksums.sha256`: package integrity support.

There is only one Protocol truth: the canonical Markdown above.

## Final status

- P00: PRESERVED
- P01: INCORPORATED_AND_FROZEN
- Phase 1 execution: ACCEPTED
- A0–A13: COMPLETE
- A14: ABSENT_PROHIBITED
- A4 R2: PROTOCOL_SYNCHRONIZED_FOR_FUTURE_DOWNSTREAM_USE
- additional P01 computation required: NO
- freeze-critical blockers: 0

The next governed step is the **Phase 1 Evidence, Results, and Interpretation Report**. The complete Phase 1 documentary lifecycle is not yet closed.

# External Artifact Retrieval Guide

No credentials are included. Private Kaggle access and source-license compliance may be required.

## P01-L1-DERIVED-WINDOWS-d03f0a7c869dd95a-20260806222242-68a91473
- Provider: Kaggle
- Dataset handle: `csthv999z/iharq-p01-l1-derived-windows-d03f0a7c869d-20260806222242-68a91473`
- Provider revision: `2`
- Logical revision: `1`
- Manifest SHA-256: `dc21f418e9a1add62adb346f627d5d729735a5f1ecaa1d771f6fa5cfede627e1`
- Size: 1,166,652,764 bytes
- Format: `LOSSLESS_HDF5_SUBJECT_SHARDS`
- Access: PRIVATE Kaggle Dataset access + source-license compliance
- Retrieval: Attach Kaggle provider dataset version 2 (IHARQ logical immutable revision 1); verify manifest SHA-256; load IHARQ_P01_L1_WINDOW_TO_SHARD_INDEX.jsonl; resolve shard filename; read declared HDF5 group/row.

## P01-L1-A4-DERIVED-WINDOWS-4cd080393345e8aa-20260807143013-663eab13
- Provider: Kaggle
- Dataset handle: `csthv999z/iharq-p01-l1-a4-d03f0a7c-9a7c6108`
- Provider revision: `1`
- Logical revision: `2`
- Manifest SHA-256: `29124d59907610b1545e0a2b5d1811a4d4a2bf1df64cad49aa880f4721c47305`
- Size: 1,357,362,334 bytes
- Format: `LOSSLESS_HDF5_MATCHED_3P5S_SUBJECT_SHARDS_WITH_REGISTERED_VIRTUAL_MULTIWINDOW_VIEWS`
- Access: PRIVATE Kaggle Dataset access + source-license compliance
- Retrieval: Attach exact private Kaggle Dataset provider version 1; verify manifest SHA-256; use registered A4 index/reader and R2 window-family freeze.

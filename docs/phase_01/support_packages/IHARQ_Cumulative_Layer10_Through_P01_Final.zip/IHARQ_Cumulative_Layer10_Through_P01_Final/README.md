# IHARQ Cumulative Layer 10 Through P01

The canonical current Layer 10 authority is `IHARQ_Cumulative_Layer10_Through_P01_Current.md`.

Layer 10 is read-only presentation/reproducibility authority. It does not supersede the cumulative Evidence Map, embedded Layer 0, Phase Analysis, Protocol, or execution evidence.

- `preserved_p00_layer10/`: byte-preserved P00 R2 Layer 10 predecessor files.
- `views/p01/`: P01 governed presentation views.
- `cards/p01/`: exact reviewed-claim and negative-state cards.
- `figures/`: source manifests plus PNG/SVG display exports.
- `tables/`: exact CSV source-value exports.
- `reproduction/`: claim/source index and safe external-artifact retrieval guide.
- `machine_readable/`: registries.
- `validation/`: deterministic read-only, parity, traceability, security and package audits.

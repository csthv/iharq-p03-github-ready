# ValidationWarning

**Source view:** `ValidationWarningView`

all limitations, blockers, unavailable environments, repairs and deferred states.


**Scope and material limits:** Current warnings include Mode B, non-empirical scope, runtime and lock limits, repaired defects, P0-GATE-18 pending, no closure, and no Phase 1 authorization.

> Read-only projection. No recomputation, evidence repair, claim approval, Phase 0 closure, or Phase 1 authorization.

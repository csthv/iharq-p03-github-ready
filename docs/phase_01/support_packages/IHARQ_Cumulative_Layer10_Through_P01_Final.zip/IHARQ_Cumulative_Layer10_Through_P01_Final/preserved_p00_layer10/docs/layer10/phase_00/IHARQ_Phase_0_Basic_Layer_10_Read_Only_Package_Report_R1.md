---
title: "IHARQ Phase 0 Basic Layer 10 Read-Only Package Report"
package_id: "P00-BASIC-LAYER10-PACKAGE-R1"
status: "COMPLETE_WITH_NONBLOCKING_LIMITATIONS"
---

# IHARQ Phase 0 Basic Layer 10 Read-Only Package Report R1

## Scope

This package is a Phase 0 basic read-only projection. It is not the complete project-wide Layer 10 or Phase 14 implementation. It consumes only saved execution, analysis, Layer 0, and accepted Evidence Map records.

## Read-only invariants

- No model fitting, metric recomputation, rematching, retuning, evidence repair, or claim approval.
- Displayed counts are loaded from saved records.
- Every claim-facing projection uses the exact Layer 0 allowed wording and mandatory warnings.
- Negative, repaired, unavailable, stale, superseded, and deferred states remain visible.
- Phase 0 closure and Phase 1 authorization remain false.

## Views

| View | Purpose |
|---|---|
| `P00PhaseStatusView` | Phase identity, scope, Mode B, engineering ceiling, closure false |
| `ProtocolStatusView` | Protocol R2 identities, 19 registered cells, timing and amendment status |
| `P00EngineeringConformanceView` | 19 registered cells and saved terminal dispositions |
| `P00DeterministicValidationView` | 102/102 saved deterministic test result |
| `P00FixtureValidationView` | 19/19 valid acceptance and 178/178 expected malformed rejection |
| `P00ArtifactClosureView` | 85 schemas, 35 configs, 79 record-family profiles |
| `P00LayerFoundationReadinessView` | L0-L10 Phase 0 foundation statuses only |
| `P00FuturePhaseContractReadinessView` | P00 implemented; P01-P15 contract-ready, not executed |
| `AblationReadinessView` | A0-A13 readiness-only and A14 rejected |
| `ValidationWarningView` | all limitations, blockers, unavailable environments, repairs and deferred states |
| `ClaimBoundaryView` | Layer 0 qualified wording, prohibited wording and warnings |
| `P00NegativeAndRepairHistoryView` | negative, not-run, repaired, stale and deferred evidence |
| `P00ReproductionAndIntegrityView` | source snapshot, Python 3.13.5, exact local lock, hashes and reproduction status |
| `ExportIntegrityView` | source IDs, versions, hashes, filters, row counts, freshness and no-recomputation |

## Package status

`P00_BASIC_LAYER10_READ_ONLY_PACKAGE_COMPLETE_WITH_NONBLOCKING_LIMITATIONS`

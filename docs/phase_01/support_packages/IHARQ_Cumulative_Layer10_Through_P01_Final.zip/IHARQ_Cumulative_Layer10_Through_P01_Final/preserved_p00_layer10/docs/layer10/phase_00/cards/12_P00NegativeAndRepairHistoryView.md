# P00NegativeAndRepairHistory

**Source view:** `P00NegativeAndRepairHistoryView`

negative, not-run, repaired, stale and deferred evidence.


**Scope and material limits:** Negative, unavailable, repaired, stale, superseded, and deferred evidence remains visible and must not be suppressed.

> Read-only projection. No recomputation, evidence repair, claim approval, Phase 0 closure, or Phase 1 authorization.

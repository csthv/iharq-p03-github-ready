# P00ReproductionAndIntegrity

**Source view:** `P00ReproductionAndIntegrityView`

source snapshot, Python 3.13.5, exact local lock, hashes and reproduction status.


**Scope and material limits:** Reproduction is exact-local only: Python 3.13.5 and the verified 22-distribution snapshot; portable cross-version reproduction is not established.

> Read-only projection. No recomputation, evidence repair, claim approval, Phase 0 closure, or Phase 1 authorization.

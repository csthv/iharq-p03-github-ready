# AblationReadiness

**Source view:** `AblationReadinessView`

A0-A13 readiness-only and A14 rejected.


**Scope and material limits:** A0-A13 are readiness-only and not activated; A14 is rejected.

> Read-only projection. No recomputation, evidence repair, claim approval, Phase 0 closure, or Phase 1 authorization.

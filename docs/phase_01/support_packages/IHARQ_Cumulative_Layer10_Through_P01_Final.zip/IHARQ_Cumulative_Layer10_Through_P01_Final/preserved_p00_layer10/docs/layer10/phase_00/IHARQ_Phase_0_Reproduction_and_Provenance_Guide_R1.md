# IHARQ Phase 0 Layer 10 Reproduction and Provenance Guide R1

1. Verify the source release and package hashes.
2. Parse the Layer 0 disposition and Evidence Map manifests.
3. Load only current saved records.
4. Apply `P00-FILTER-ALL-CURRENT-R1`; disclose all filtering.
5. Render the 14 views and corresponding cards from source fields without recomputation.
6. Verify limitation, negative-evidence, and warning parity.
7. Verify export hashes and no source mutation.

The guide does not authorize Phase 0 closure or Phase 1.

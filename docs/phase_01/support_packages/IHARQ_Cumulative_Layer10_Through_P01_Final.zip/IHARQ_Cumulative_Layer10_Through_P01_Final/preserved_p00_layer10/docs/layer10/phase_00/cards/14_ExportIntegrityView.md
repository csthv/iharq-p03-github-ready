# ExportIntegrity

**Source view:** `ExportIntegrityView`

source IDs, versions, hashes, filters, row counts, freshness and no-recomputation.


**Scope and material limits:** Exports use current R2 releases, disclosed filters, exact source values, and no recomputation; stale predecessors remain historical.

> Read-only projection. No recomputation, evidence repair, claim approval, Phase 0 closure, or Phase 1 authorization.

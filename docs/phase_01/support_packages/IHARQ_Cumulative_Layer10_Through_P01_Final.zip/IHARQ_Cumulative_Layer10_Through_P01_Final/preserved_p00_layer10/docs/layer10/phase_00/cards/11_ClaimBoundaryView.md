# ClaimBoundary

**Source view:** `ClaimBoundaryView`

Layer 0 qualified wording, prohibited wording and warnings.


**Scope and material limits:** Only current v2 qualified claim wording is authorized; no claim strengthening or scientific upgrade is permitted.

> Read-only projection. No recomputation, evidence repair, claim approval, Phase 0 closure, or Phase 1 authorization.

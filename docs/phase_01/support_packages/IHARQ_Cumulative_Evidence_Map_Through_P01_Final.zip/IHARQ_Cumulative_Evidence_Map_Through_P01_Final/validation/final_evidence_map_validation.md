# Final Cumulative Evidence Map Validation

**Status:** `PASS`
**Checks:** 456/456 PASS
**Failures:** 0

## Key closure

- P00 rows preserved: 7/7
- P01 reviewed claims mapped: 12/12
- Supported/qualified cumulative claims: 17
- P01 supported/qualified: 10
- P01 deferred: 1
- P01 rejected: 1
- P01 bundle checksum rows independently verified: 13164/13164
- DOCX visually reviewed: 42/42 pages
- Freeze-critical blockers: 0

## Checks

| Check | Result | Detail |
|---|---|---|
| `canonical_md_exists` | **PASS** | IHARQ_Cumulative_Paper_and_Thesis_Evidence_Map_Through_P01_Current.md |
| `docx_exists` | **PASS** | IHARQ_Cumulative_Paper_and_Thesis_Evidence_Map_Through_P01_Current.docx |
| `canonical_map_id` | **PASS** |  |
| `release_id` | **PASS** |  |
| `final_status_string` | **PASS** |  |
| `layer10_ready_string` | **PASS** |  |
| `md_authority_statement` | **PASS** |  |
| `p00_row_count` | **PASS** | 7 |
| `p00_source_count` | **PASS** | 7 |
| `p00_release_r2` | **PASS** |  |
| `p00_annex_hash` | **PASS** | ece1471edf1e117770e7cd3966a61267fd51a726a72630929fd70a1a06a80fd6 |
| `P00-CLM-001/v2:exists` | **PASS** |  |
| `P00-CLM-001/v2:wording_exact` | **PASS** |  |
| `P00-CLM-001/v2:wording_hash` | **PASS** |  |
| `P00-CLM-001/v2:disposition_exact` | **PASS** |  |
| `P00-CLM-001/v2:disposition_id_exact` | **PASS** |  |
| `P00-CLM-001/v2:finding_exact` | **PASS** |  |
| `P00-CLM-001/v2:limitations_exact` | **PASS** |  |
| `P00-CLM-001/v2:negative_links_exact` | **PASS** |  |
| `P00-CLM-001/v2:lifecycle_exact` | **PASS** |  |
| `P00-CLM-001/v2:source_slots_preserved` | **PASS** |  |
| `P00-CLM-001/v2:layer10_views_typed` | **PASS** | ['ClaimBoundaryView', 'P00PhaseStatusView'] |
| `P00-CLM-001/v2:layer10_card_typed` | **PASS** |  |
| `P00-CLM-001/v2:layer10_export_typed` | **PASS** |  |
| `P00-CLM-002/v2:exists` | **PASS** |  |
| `P00-CLM-002/v2:wording_exact` | **PASS** |  |
| `P00-CLM-002/v2:wording_hash` | **PASS** |  |
| `P00-CLM-002/v2:disposition_exact` | **PASS** |  |
| `P00-CLM-002/v2:disposition_id_exact` | **PASS** |  |
| `P00-CLM-002/v2:finding_exact` | **PASS** |  |
| `P00-CLM-002/v2:limitations_exact` | **PASS** |  |
| `P00-CLM-002/v2:negative_links_exact` | **PASS** |  |
| `P00-CLM-002/v2:lifecycle_exact` | **PASS** |  |
| `P00-CLM-002/v2:source_slots_preserved` | **PASS** |  |
| `P00-CLM-002/v2:layer10_views_typed` | **PASS** | ['ClaimBoundaryView', 'P00PhaseStatusView'] |
| `P00-CLM-002/v2:layer10_card_typed` | **PASS** |  |
| `P00-CLM-002/v2:layer10_export_typed` | **PASS** |  |
| `P00-CLM-003/v2:exists` | **PASS** |  |
| `P00-CLM-003/v2:wording_exact` | **PASS** |  |
| `P00-CLM-003/v2:wording_hash` | **PASS** |  |
| `P00-CLM-003/v2:disposition_exact` | **PASS** |  |
| `P00-CLM-003/v2:disposition_id_exact` | **PASS** |  |
| `P00-CLM-003/v2:finding_exact` | **PASS** |  |
| `P00-CLM-003/v2:limitations_exact` | **PASS** |  |
| `P00-CLM-003/v2:negative_links_exact` | **PASS** |  |
| `P00-CLM-003/v2:lifecycle_exact` | **PASS** |  |
| `P00-CLM-003/v2:source_slots_preserved` | **PASS** |  |
| `P00-CLM-003/v2:layer10_views_typed` | **PASS** | ['ClaimBoundaryView', 'P00PhaseStatusView'] |
| `P00-CLM-003/v2:layer10_card_typed` | **PASS** |  |
| `P00-CLM-003/v2:layer10_export_typed` | **PASS** |  |
| `P00-CLM-004/v2:exists` | **PASS** |  |
| `P00-CLM-004/v2:wording_exact` | **PASS** |  |
| `P00-CLM-004/v2:wording_hash` | **PASS** |  |
| `P00-CLM-004/v2:disposition_exact` | **PASS** |  |
| `P00-CLM-004/v2:disposition_id_exact` | **PASS** |  |
| `P00-CLM-004/v2:finding_exact` | **PASS** |  |
| `P00-CLM-004/v2:limitations_exact` | **PASS** |  |
| `P00-CLM-004/v2:negative_links_exact` | **PASS** |  |
| `P00-CLM-004/v2:lifecycle_exact` | **PASS** |  |
| `P00-CLM-004/v2:source_slots_preserved` | **PASS** |  |
| `P00-CLM-004/v2:layer10_views_typed` | **PASS** | ['ClaimBoundaryView', 'P00PhaseStatusView'] |
| `P00-CLM-004/v2:layer10_card_typed` | **PASS** |  |
| `P00-CLM-004/v2:layer10_export_typed` | **PASS** |  |
| `P00-CLM-005/v2:exists` | **PASS** |  |
| `P00-CLM-005/v2:wording_exact` | **PASS** |  |
| `P00-CLM-005/v2:wording_hash` | **PASS** |  |
| `P00-CLM-005/v2:disposition_exact` | **PASS** |  |
| `P00-CLM-005/v2:disposition_id_exact` | **PASS** |  |
| `P00-CLM-005/v2:finding_exact` | **PASS** |  |
| `P00-CLM-005/v2:limitations_exact` | **PASS** |  |
| `P00-CLM-005/v2:negative_links_exact` | **PASS** |  |
| `P00-CLM-005/v2:lifecycle_exact` | **PASS** |  |
| `P00-CLM-005/v2:source_slots_preserved` | **PASS** |  |
| `P00-CLM-005/v2:layer10_views_typed` | **PASS** | ['ClaimBoundaryView', 'P00PhaseStatusView'] |
| `P00-CLM-005/v2:layer10_card_typed` | **PASS** |  |
| `P00-CLM-005/v2:layer10_export_typed` | **PASS** |  |
| `P00-CLM-006/v2:exists` | **PASS** |  |
| `P00-CLM-006/v2:wording_exact` | **PASS** |  |
| `P00-CLM-006/v2:wording_hash` | **PASS** |  |
| `P00-CLM-006/v2:disposition_exact` | **PASS** |  |
| `P00-CLM-006/v2:disposition_id_exact` | **PASS** |  |
| `P00-CLM-006/v2:finding_exact` | **PASS** |  |
| `P00-CLM-006/v2:limitations_exact` | **PASS** |  |
| `P00-CLM-006/v2:negative_links_exact` | **PASS** |  |
| `P00-CLM-006/v2:lifecycle_exact` | **PASS** |  |
| `P00-CLM-006/v2:source_slots_preserved` | **PASS** |  |
| `P00-CLM-006/v2:layer10_views_typed` | **PASS** | ['ClaimBoundaryView', 'P00PhaseStatusView'] |
| `P00-CLM-006/v2:layer10_card_typed` | **PASS** |  |
| `P00-CLM-006/v2:layer10_export_typed` | **PASS** |  |
| `P00-CLM-007/v2:exists` | **PASS** |  |
| `P00-CLM-007/v2:wording_exact` | **PASS** |  |
| `P00-CLM-007/v2:wording_hash` | **PASS** |  |
| `P00-CLM-007/v2:disposition_exact` | **PASS** |  |
| `P00-CLM-007/v2:disposition_id_exact` | **PASS** |  |
| `P00-CLM-007/v2:finding_exact` | **PASS** |  |
| `P00-CLM-007/v2:limitations_exact` | **PASS** |  |
| `P00-CLM-007/v2:negative_links_exact` | **PASS** |  |
| `P00-CLM-007/v2:lifecycle_exact` | **PASS** |  |
| `P00-CLM-007/v2:source_slots_preserved` | **PASS** |  |
| `P00-CLM-007/v2:layer10_views_typed` | **PASS** | ['ClaimBoundaryView', 'P00PhaseStatusView'] |
| `P00-CLM-007/v2:layer10_card_typed` | **PASS** |  |
| `P00-CLM-007/v2:layer10_export_typed` | **PASS** |  |
| `p01_row_count` | **PASS** | 12 |
| `p01_source_count` | **PASS** | 12 |
| `P01-CLM-001/v1:exists` | **PASS** |  |
| `P01-CLM-001/v1:candidate_exact` | **PASS** |  |
| `P01-CLM-001/v1:wording_exact` | **PASS** |  |
| `P01-CLM-001/v1:wording_hash` | **PASS** |  |
| `P01-CLM-001/v1:disposition_exact` | **PASS** |  |
| `P01-CLM-001/v1:disposition_id_exact` | **PASS** |  |
| `P01-CLM-001/v1:finding_exact` | **PASS** |  |
| `P01-CLM-001/v1:protocol_exact` | **PASS** |  |
| `P01-CLM-001/v1:run_exact` | **PASS** |  |
| `P01-CLM-001/v1:record_no_fabrication` | **PASS** | set() |
| `P01-CLM-001/v1:limitations_exact` | **PASS** |  |
| `P01-CLM-001/v1:wording_in_markdown` | **PASS** |  |
| `P01-CLM-002/v1:exists` | **PASS** |  |
| `P01-CLM-002/v1:candidate_exact` | **PASS** |  |
| `P01-CLM-002/v1:wording_exact` | **PASS** |  |
| `P01-CLM-002/v1:wording_hash` | **PASS** |  |
| `P01-CLM-002/v1:disposition_exact` | **PASS** |  |
| `P01-CLM-002/v1:disposition_id_exact` | **PASS** |  |
| `P01-CLM-002/v1:finding_exact` | **PASS** |  |
| `P01-CLM-002/v1:protocol_exact` | **PASS** |  |
| `P01-CLM-002/v1:run_exact` | **PASS** |  |
| `P01-CLM-002/v1:record_no_fabrication` | **PASS** | set() |
| `P01-CLM-002/v1:limitations_exact` | **PASS** |  |
| `P01-CLM-002/v1:wording_in_markdown` | **PASS** |  |
| `P01-CLM-003/v1:exists` | **PASS** |  |
| `P01-CLM-003/v1:candidate_exact` | **PASS** |  |
| `P01-CLM-003/v1:wording_exact` | **PASS** |  |
| `P01-CLM-003/v1:wording_hash` | **PASS** |  |
| `P01-CLM-003/v1:disposition_exact` | **PASS** |  |
| `P01-CLM-003/v1:disposition_id_exact` | **PASS** |  |
| `P01-CLM-003/v1:finding_exact` | **PASS** |  |
| `P01-CLM-003/v1:protocol_exact` | **PASS** |  |
| `P01-CLM-003/v1:run_exact` | **PASS** |  |
| `P01-CLM-003/v1:record_no_fabrication` | **PASS** | set() |
| `P01-CLM-003/v1:limitations_exact` | **PASS** |  |
| `P01-CLM-003/v1:wording_in_markdown` | **PASS** |  |
| `P01-CLM-004/v1:exists` | **PASS** |  |
| `P01-CLM-004/v1:candidate_exact` | **PASS** |  |
| `P01-CLM-004/v1:wording_exact` | **PASS** |  |
| `P01-CLM-004/v1:wording_hash` | **PASS** |  |
| `P01-CLM-004/v1:disposition_exact` | **PASS** |  |
| `P01-CLM-004/v1:disposition_id_exact` | **PASS** |  |
| `P01-CLM-004/v1:finding_exact` | **PASS** |  |
| `P01-CLM-004/v1:protocol_exact` | **PASS** |  |
| `P01-CLM-004/v1:run_exact` | **PASS** |  |
| `P01-CLM-004/v1:record_no_fabrication` | **PASS** | set() |
| `P01-CLM-004/v1:limitations_exact` | **PASS** |  |
| `P01-CLM-004/v1:wording_in_markdown` | **PASS** |  |
| `P01-CLM-005/v1:exists` | **PASS** |  |
| `P01-CLM-005/v1:candidate_exact` | **PASS** |  |
| `P01-CLM-005/v1:wording_exact` | **PASS** |  |
| `P01-CLM-005/v1:wording_hash` | **PASS** |  |
| `P01-CLM-005/v1:disposition_exact` | **PASS** |  |
| `P01-CLM-005/v1:disposition_id_exact` | **PASS** |  |
| `P01-CLM-005/v1:finding_exact` | **PASS** |  |
| `P01-CLM-005/v1:protocol_exact` | **PASS** |  |
| `P01-CLM-005/v1:run_exact` | **PASS** |  |
| `P01-CLM-005/v1:record_no_fabrication` | **PASS** | set() |
| `P01-CLM-005/v1:limitations_exact` | **PASS** |  |
| `P01-CLM-005/v1:wording_in_markdown` | **PASS** |  |
| `P01-CLM-006/v1:exists` | **PASS** |  |
| `P01-CLM-006/v1:candidate_exact` | **PASS** |  |
| `P01-CLM-006/v1:wording_exact` | **PASS** |  |
| `P01-CLM-006/v1:wording_hash` | **PASS** |  |
| `P01-CLM-006/v1:disposition_exact` | **PASS** |  |
| `P01-CLM-006/v1:disposition_id_exact` | **PASS** |  |
| `P01-CLM-006/v1:finding_exact` | **PASS** |  |
| `P01-CLM-006/v1:protocol_exact` | **PASS** |  |
| `P01-CLM-006/v1:run_exact` | **PASS** |  |
| `P01-CLM-006/v1:record_no_fabrication` | **PASS** | set() |
| `P01-CLM-006/v1:limitations_exact` | **PASS** |  |
| `P01-CLM-006/v1:wording_in_markdown` | **PASS** |  |
| `P01-CLM-007/v1:exists` | **PASS** |  |
| `P01-CLM-007/v1:candidate_exact` | **PASS** |  |
| `P01-CLM-007/v1:wording_exact` | **PASS** |  |
| `P01-CLM-007/v1:wording_hash` | **PASS** |  |
| `P01-CLM-007/v1:disposition_exact` | **PASS** |  |
| `P01-CLM-007/v1:disposition_id_exact` | **PASS** |  |
| `P01-CLM-007/v1:finding_exact` | **PASS** |  |
| `P01-CLM-007/v1:protocol_exact` | **PASS** |  |
| `P01-CLM-007/v1:run_exact` | **PASS** |  |
| `P01-CLM-007/v1:record_no_fabrication` | **PASS** | set() |
| `P01-CLM-007/v1:limitations_exact` | **PASS** |  |
| `P01-CLM-007/v1:wording_in_markdown` | **PASS** |  |
| `P01-CLM-008/v1:exists` | **PASS** |  |
| `P01-CLM-008/v1:candidate_exact` | **PASS** |  |
| `P01-CLM-008/v1:wording_exact` | **PASS** |  |
| `P01-CLM-008/v1:wording_hash` | **PASS** |  |
| `P01-CLM-008/v1:disposition_exact` | **PASS** |  |
| `P01-CLM-008/v1:disposition_id_exact` | **PASS** |  |
| `P01-CLM-008/v1:finding_exact` | **PASS** |  |
| `P01-CLM-008/v1:protocol_exact` | **PASS** |  |
| `P01-CLM-008/v1:run_exact` | **PASS** |  |
| `P01-CLM-008/v1:record_no_fabrication` | **PASS** | set() |
| `P01-CLM-008/v1:limitations_exact` | **PASS** |  |
| `P01-CLM-008/v1:wording_in_markdown` | **PASS** |  |
| `P01-CLM-009/v1:exists` | **PASS** |  |
| `P01-CLM-009/v1:candidate_exact` | **PASS** |  |
| `P01-CLM-009/v1:wording_exact` | **PASS** |  |
| `P01-CLM-009/v1:wording_hash` | **PASS** |  |
| `P01-CLM-009/v1:disposition_exact` | **PASS** |  |
| `P01-CLM-009/v1:disposition_id_exact` | **PASS** |  |
| `P01-CLM-009/v1:finding_exact` | **PASS** |  |
| `P01-CLM-009/v1:protocol_exact` | **PASS** |  |
| `P01-CLM-009/v1:run_exact` | **PASS** |  |
| `P01-CLM-009/v1:record_no_fabrication` | **PASS** | set() |
| `P01-CLM-009/v1:limitations_exact` | **PASS** |  |
| `P01-CLM-009/v1:wording_in_markdown` | **PASS** |  |
| `P01-CLM-010/v1:exists` | **PASS** |  |
| `P01-CLM-010/v1:candidate_exact` | **PASS** |  |
| `P01-CLM-010/v1:wording_exact` | **PASS** |  |
| `P01-CLM-010/v1:wording_hash` | **PASS** |  |
| `P01-CLM-010/v1:disposition_exact` | **PASS** |  |
| `P01-CLM-010/v1:disposition_id_exact` | **PASS** |  |
| `P01-CLM-010/v1:finding_exact` | **PASS** |  |
| `P01-CLM-010/v1:protocol_exact` | **PASS** |  |
| `P01-CLM-010/v1:run_exact` | **PASS** |  |
| `P01-CLM-010/v1:record_no_fabrication` | **PASS** | set() |
| `P01-CLM-010/v1:limitations_exact` | **PASS** |  |
| `P01-CLM-010/v1:wording_in_markdown` | **PASS** |  |
| `P01-CLM-011/v1:exists` | **PASS** |  |
| `P01-CLM-011/v1:candidate_exact` | **PASS** |  |
| `P01-CLM-011/v1:wording_exact` | **PASS** |  |
| `P01-CLM-011/v1:wording_hash` | **PASS** |  |
| `P01-CLM-011/v1:disposition_exact` | **PASS** |  |
| `P01-CLM-011/v1:disposition_id_exact` | **PASS** |  |
| `P01-CLM-011/v1:finding_exact` | **PASS** |  |
| `P01-CLM-011/v1:protocol_exact` | **PASS** |  |
| `P01-CLM-011/v1:run_exact` | **PASS** |  |
| `P01-CLM-011/v1:record_no_fabrication` | **PASS** | set() |
| `P01-CLM-011/v1:limitations_exact` | **PASS** |  |
| `P01-CLM-011/v1:wording_in_markdown` | **PASS** |  |
| `P01-CLM-012/v1:exists` | **PASS** |  |
| `P01-CLM-012/v1:candidate_exact` | **PASS** |  |
| `P01-CLM-012/v1:wording_exact` | **PASS** |  |
| `P01-CLM-012/v1:wording_hash` | **PASS** |  |
| `P01-CLM-012/v1:disposition_exact` | **PASS** |  |
| `P01-CLM-012/v1:disposition_id_exact` | **PASS** |  |
| `P01-CLM-012/v1:finding_exact` | **PASS** |  |
| `P01-CLM-012/v1:protocol_exact` | **PASS** |  |
| `P01-CLM-012/v1:run_exact` | **PASS** |  |
| `P01-CLM-012/v1:record_no_fabrication` | **PASS** | set() |
| `P01-CLM-012/v1:limitations_exact` | **PASS** |  |
| `P01-CLM-012/v1:wording_in_markdown` | **PASS** |  |
| `p01_disposition_distribution` | **PASS** | {'APPROVED_WITH_QUALIFICATIONS': 8, 'APPROVED': 2, 'DEFERRED': 1, 'REJECTED': 1} |
| `p01_no_blocked` | **PASS** |  |
| `claim011_deferred` | **PASS** |  |
| `claim012_rejected` | **PASS** |  |
| `supported_cumulative_count` | **PASS** | 17 |
| `supported_p01_count` | **PASS** |  |
| `P00-CLM-001/v2:supported_has_findings` | **PASS** |  |
| `P00-CLM-002/v2:supported_has_findings` | **PASS** |  |
| `P00-CLM-003/v2:supported_has_findings` | **PASS** |  |
| `P00-CLM-004/v2:supported_has_findings` | **PASS** |  |
| `P00-CLM-005/v2:supported_has_findings` | **PASS** |  |
| `P00-CLM-006/v2:supported_has_findings` | **PASS** |  |
| `P00-CLM-007/v2:supported_has_findings` | **PASS** |  |
| `P01-CLM-001/v1:supported_has_findings` | **PASS** |  |
| `P01-CLM-002/v1:supported_has_findings` | **PASS** |  |
| `P01-CLM-003/v1:supported_has_findings` | **PASS** |  |
| `P01-CLM-004/v1:supported_has_findings` | **PASS** |  |
| `P01-CLM-005/v1:supported_has_findings` | **PASS** |  |
| `P01-CLM-006/v1:supported_has_findings` | **PASS** |  |
| `P01-CLM-007/v1:supported_has_findings` | **PASS** |  |
| `P01-CLM-008/v1:supported_has_findings` | **PASS** |  |
| `P01-CLM-009/v1:supported_has_findings` | **PASS** |  |
| `P01-CLM-010/v1:supported_has_findings` | **PASS** |  |
| `P01-CLM-001/v1:finding_fk:P01-FIND-001` | **PASS** |  |
| `P01-CLM-001/v1:stage_valid:P01-STAGE-05` | **PASS** | P01-STAGE-05 |
| `P01-CLM-001/v1:stage_valid:P01-STAGE-06` | **PASS** | P01-STAGE-06 |
| `P01-CLM-001/v1:stage_valid:P01-STAGE-07` | **PASS** | P01-STAGE-07 |
| `P01-CLM-001/v1:path:records/datasets/BNCI2014_001/IHARQ-DATASETRECORD-20260806-42c424800627b6ee.json` | **PASS** | records/datasets/BNCI2014_001/IHARQ-DATASETRECORD-20260806-42c424800627b6ee.json |
| `P01-CLM-001/v1:path:records/datasets/Lee2019_MI/IHARQ-DATASETRECORD-20260806-adb91f25a65e588e.json` | **PASS** | records/datasets/Lee2019_MI/IHARQ-DATASETRECORD-20260806-adb91f25a65e588e.json |
| `P01-CLM-001/v1:path:records/datasets/PhysioNetMI/IHARQ-DATASETRECORD-20260806-66309cda68771bef.json` | **PASS** | records/datasets/PhysioNetMI/IHARQ-DATASETRECORD-20260806-66309cda68771bef.json |
| `P01-CLM-001/v1:path:reports/phase_01/sources/source_version_license_report.json` | **PASS** | reports/phase_01/sources/source_version_license_report.json |
| `P01-CLM-002/v1:finding_fk:P01-FIND-002` | **PASS** |  |
| `P01-CLM-002/v1:finding_fk:P01-FIND-006` | **PASS** |  |
| `P01-CLM-002/v1:stage_valid:P01-STAGE-11` | **PASS** | P01-STAGE-11 |
| `P01-CLM-002/v1:stage_valid:P01-STAGE-17` | **PASS** | P01-STAGE-17 |
| `P01-CLM-002/v1:path:records/splits/P01-L1-SPLIT-OFFICIAL-R2/IHARQ-SPLITRECORD-20260806-e4e371d332c61e36.json` | **PASS** | records/splits/P01-L1-SPLIT-OFFICIAL-R2/IHARQ-SPLITRECORD-20260806-e4e371d332c61e36.json |
| `P01-CLM-002/v1:path:reports/phase_01/splits/disjointness.json` | **PASS** | reports/phase_01/splits/disjointness.json |
| `P01-CLM-002/v1:path:reports/phase_01/leakage/leakage_contamination.json` | **PASS** | reports/phase_01/leakage/leakage_contamination.json |
| `P01-CLM-003/v1:finding_fk:P01-FIND-003` | **PASS** |  |
| `P01-CLM-003/v1:stage_valid:P01-STAGE-13` | **PASS** | P01-STAGE-13 |
| `P01-CLM-003/v1:stage_valid:P01-STAGE-14` | **PASS** | P01-STAGE-14 |
| `P01-CLM-003/v1:stage_valid:P01-STAGE-16` | **PASS** | P01-STAGE-16 |
| `P01-CLM-003/v1:path:records/windows/` | **PASS** | records/windows/ |
| `P01-CLM-003/v1:path:external_artifact_pointers/derived_windows_dataset.json` | **PASS** | external_artifact_pointers/derived_windows_dataset.json |
| `P01-CLM-004/v1:finding_fk:P01-FIND-004` | **PASS** |  |
| `P01-CLM-004/v1:stage_valid:P01-STAGE-14` | **PASS** | P01-STAGE-14 |
| `P01-CLM-004/v1:stage_valid:P01-STAGE-15` | **PASS** | P01-STAGE-15 |
| `P01-CLM-004/v1:stage_valid:P01-STAGE-20` | **PASS** | P01-STAGE-20 |
| `P01-CLM-004/v1:path:reports/phase_01/storage/existing_core_dataset_adoption.json` | **PASS** | reports/phase_01/storage/existing_core_dataset_adoption.json |
| `P01-CLM-004/v1:path:external_artifact_pointers/derived_windows_dataset.json` | **PASS** | external_artifact_pointers/derived_windows_dataset.json |
| `P01-CLM-005/v1:finding_fk:P01-FIND-005` | **PASS** |  |
| `P01-CLM-005/v1:stage_valid:P01-STAGE-13` | **PASS** | P01-STAGE-13 |
| `P01-CLM-005/v1:stage_valid:P01-STAGE-16` | **PASS** | P01-STAGE-16 |
| `P01-CLM-005/v1:path:reports/phase_01/quality/quality_coverage.json` | **PASS** | reports/phase_01/quality/quality_coverage.json |
| `P01-CLM-005/v1:path:records/quality/` | **PASS** | records/quality/ |
| `P01-CLM-006/v1:finding_fk:P01-FIND-008` | **PASS** |  |
| `P01-CLM-006/v1:stage_valid:P01-STAGE-18` | **PASS** | P01-STAGE-18 |
| `P01-CLM-006/v1:path:manifests/phase_01/layer1_ablation_readiness_l1_v1.json` | **PASS** | manifests/phase_01/layer1_ablation_readiness_l1_v1.json |
| `P01-CLM-007/v1:finding_fk:P01-FIND-009` | **PASS** |  |
| `P01-CLM-007/v1:finding_fk:P01-FIND-010` | **PASS** |  |
| `P01-CLM-007/v1:stage_valid:P01-STAGE-14` | **PASS** | P01-STAGE-14 |
| `P01-CLM-007/v1:stage_valid:P01-STAGE-15` | **PASS** | P01-STAGE-15 |
| `P01-CLM-007/v1:stage_valid:P01-STAGE-18` | **PASS** | P01-STAGE-18 |
| `P01-CLM-007/v1:path:external_artifact_pointers/a4_window_family_dataset.json` | **PASS** | external_artifact_pointers/a4_window_family_dataset.json |
| `P01-CLM-007/v1:path:reports/phase_01/storage/a4_derived_output_storage_actual_precommit.json` | **PASS** | reports/phase_01/storage/a4_derived_output_storage_actual_precommit.json |
| `P01-CLM-007/v1:path:config_snapshot/p01_l1_a4_window_family_freeze_R2.json` | **PASS** | config_snapshot/p01_l1_a4_window_family_freeze_R2.json |
| `P01-CLM-008/v1:finding_fk:P01-FIND-012` | **PASS** |  |
| `P01-CLM-008/v1:stage_valid:P01-STAGE-04` | **PASS** | P01-STAGE-04 |
| `P01-CLM-008/v1:stage_valid:P01-STAGE-23` | **PASS** | P01-STAGE-23 |
| `P01-CLM-008/v1:stage_valid:P01-STAGE-24` | **PASS** | P01-STAGE-24 |
| `P01-CLM-008/v1:stage_valid:P01-STAGE-26` | **PASS** | P01-STAGE-26 |
| `P01-CLM-008/v1:path:reports/phase_01/tests/stage_results.json` | **PASS** | reports/phase_01/tests/stage_results.json |
| `P01-CLM-008/v1:path:gate_decision.json` | **PASS** | gate_decision.json |
| `P01-CLM-008/v1:path:reports/phase_01/tests/phase0_and_runtime_regression.json` | **PASS** | reports/phase_01/tests/phase0_and_runtime_regression.json |
| `P01-CLM-008/v1:path:reports/phase_01/repair_reentry.json` | **PASS** | reports/phase_01/repair_reentry.json |
| `P01-CLM-008/v1:path:checksums.sha256` | **PASS** | checksums.sha256 |
| `P01-CLM-009/v1:finding_fk:P01-FIND-011` | **PASS** |  |
| `P01-CLM-009/v1:stage_valid:P01-STAGE-01` | **PASS** | P01-STAGE-01 |
| `P01-CLM-009/v1:stage_valid:P01-STAGE-03` | **PASS** | P01-STAGE-03 |
| `P01-CLM-009/v1:path:environment_manifest.json` | **PASS** | environment_manifest.json |
| `P01-CLM-009/v1:path:environment_amendment.json` | **PASS** | environment_amendment.json |
| `P01-CLM-010/v1:finding_fk:P01-FIND-014` | **PASS** |  |
| `P01-CLM-010/v1:stage_valid:P01-STAGE-22` | **PASS** | P01-STAGE-22 |
| `P01-CLM-010/v1:stage_valid:P01-STAGE-23` | **PASS** | P01-STAGE-23 |
| `P01-CLM-010/v1:stage_valid:P01-STAGE-26` | **PASS** | P01-STAGE-26 |
| `P01-CLM-010/v1:path:handoffs/phase_01_to_phase_02.yaml` | **PASS** | handoffs/phase_01_to_phase_02.yaml |
| `P01-CLM-010/v1:path:phase2_handoff/phase_01_to_phase_02.yaml` | **PASS** | phase2_handoff/phase_01_to_phase_02.yaml |
| `P01-CLM-011/v1:finding_fk:P01-FIND-009` | **PASS** |  |
| `P01-CLM-011/v1:stage_valid:P01-STAGE-14` | **PASS** | P01-STAGE-14 |
| `P01-CLM-011/v1:stage_valid:P01-STAGE-15` | **PASS** | P01-STAGE-15 |
| `P01-CLM-011/v1:path:external_artifact_pointers/a4_window_family_dataset.json` | **PASS** | external_artifact_pointers/a4_window_family_dataset.json |
| `P01-CLM-011/v1:path:config_snapshot/p01_l1_a4_window_family_freeze_R2.json` | **PASS** | config_snapshot/p01_l1_a4_window_family_freeze_R2.json |
| `P01-CLM-012/v1:finding_fk:P01-FIND-001` | **PASS** |  |
| `P01-CLM-012/v1:finding_fk:P01-FIND-012` | **PASS** |  |
| `P01-CLM-012/v1:stage_valid:P01-STAGE-06` | **PASS** | P01-STAGE-06 |
| `P01-CLM-012/v1:stage_valid:P01-STAGE-26` | **PASS** | P01-STAGE-26 |
| `P01-CLM-012/v1:path:reports/phase_01/sources/source_version_license_report.json` | **PASS** | reports/phase_01/sources/source_version_license_report.json |
| `P01-CLM-012/v1:path:gate_decision.json` | **PASS** | gate_decision.json |
| `deferred_not_supported` | **PASS** |  |
| `deferred_layer10_not_supported` | **PASS** |  |
| `rejected_not_supported` | **PASS** |  |
| `rejected_layer10_not_supported` | **PASS** |  |
| `a4_no_effectiveness_claim` | **PASS** |  |
| `clinical_not_supported` | **PASS** |  |
| `leakage_bounded` | **PASS** |  |
| `a0_a13_exact` | **PASS** | ['A0', 'A1', 'A10', 'A11', 'A12', 'A13', 'A2', 'A3', 'A4', 'A5', 'A6', 'A7', 'A8', 'A9'] |
| `a14_absent` | **PASS** |  |
| `a4_claim007_qualified` | **PASS** |  |
| `a4_claim011_deferred` | **PASS** |  |
| `a4_warning_present` | **PASS** |  |
| `external_artifact_count_2` | **PASS** | 2 |
| `core_provider_v2` | **PASS** | 2 |
| `core_logical_rev1` | **PASS** | 1 |
| `core_manifest_hash` | **PASS** |  |
| `a4_provider_v1` | **PASS** | 1 |
| `a4_logical_rev2` | **PASS** | 2 |
| `a4_manifest_hash` | **PASS** |  |
| `core_retrieval_disambiguates_versions` | **PASS** |  |
| `claim_evidence_matrix.csv:row_count` | **PASS** | 19 |
| `manuscript_and_output_placement_map.csv:row_count` | **PASS** | 19 |
| `reproduction_asset_map.csv:row_count` | **PASS** | 19 |
| `limitation_and_warning_propagation.csv:row_count` | **PASS** | 37 |
| `negative_and_deferred_claim_map.csv:row_count` | **PASS** | 6 |
| `figure_table_card_source_map.csv:row_count` | **PASS** | 10 |
| `typed_layer10_view_column` | **PASS** |  |
| `typed_layer10_export_column` | **PASS** |  |
| `predecessor_layer10_slots_column` | **PASS** |  |
| `parse_yaml:external_artifact_map.yaml` | **PASS** |  |
| `parse_yaml:claim_evidence_manifest.yaml` | **PASS** |  |
| `parse_yaml:evidence_map_handoff.yaml` | **PASS** |  |
| `parse_json:p01_mapping_completeness.json` | **PASS** |  |
| `parse_json:human_machine_no_drift.json` | **PASS** |  |
| `parse_json:docx_a11y_audit.json` | **PASS** |  |
| `parse_json:docx_a11y_fix_report.json` | **PASS** |  |
| `parse_json:foreign_key_validation.json` | **PASS** |  |
| `parse_json:path_resolution_validation.json` | **PASS** |  |
| `parse_json:p00_preservation_audit.json` | **PASS** |  |
| `parse_json:final_evidence_map_validation.json` | **PASS** |  |
| `parse_json:source_utilization_audit.json` | **PASS** |  |
| `parse_json:reviewed_wording_parity.json` | **PASS** |  |
| `parse_json:limitation_parity.json` | **PASS** |  |
| `parse_json:evidence_map_release_manifest.json` | **PASS** |  |
| `no_TODO` | **PASS** |  |
| `no_TBD` | **PASS** |  |
| `no_FIXME` | **PASS** |  |
| `no_template_double_brackets` | **PASS** |  |
| `no_transient_mnt_path` | **PASS** |  |
| `evidence_map_non_authorizing` | **PASS** |  |
| `docx_final_status` | **PASS** |  |
| `docx_claim:P00-CLM-001/v2` | **PASS** |  |
| `docx_wording:P00-CLM-001/v2` | **PASS** |  |
| `docx_claim:P00-CLM-002/v2` | **PASS** |  |
| `docx_wording:P00-CLM-002/v2` | **PASS** |  |
| `docx_claim:P00-CLM-003/v2` | **PASS** |  |
| `docx_wording:P00-CLM-003/v2` | **PASS** |  |
| `docx_claim:P00-CLM-004/v2` | **PASS** |  |
| `docx_wording:P00-CLM-004/v2` | **PASS** |  |
| `docx_claim:P00-CLM-005/v2` | **PASS** |  |
| `docx_wording:P00-CLM-005/v2` | **PASS** |  |
| `docx_claim:P00-CLM-006/v2` | **PASS** |  |
| `docx_wording:P00-CLM-006/v2` | **PASS** |  |
| `docx_claim:P00-CLM-007/v2` | **PASS** |  |
| `docx_wording:P00-CLM-007/v2` | **PASS** |  |
| `docx_claim:P01-CLM-001/v1` | **PASS** |  |
| `docx_wording:P01-CLM-001/v1` | **PASS** |  |
| `docx_claim:P01-CLM-002/v1` | **PASS** |  |
| `docx_wording:P01-CLM-002/v1` | **PASS** |  |
| `docx_claim:P01-CLM-003/v1` | **PASS** |  |
| `docx_wording:P01-CLM-003/v1` | **PASS** |  |
| `docx_claim:P01-CLM-004/v1` | **PASS** |  |
| `docx_wording:P01-CLM-004/v1` | **PASS** |  |
| `docx_claim:P01-CLM-005/v1` | **PASS** |  |
| `docx_wording:P01-CLM-005/v1` | **PASS** |  |
| `docx_claim:P01-CLM-006/v1` | **PASS** |  |
| `docx_wording:P01-CLM-006/v1` | **PASS** |  |
| `docx_claim:P01-CLM-007/v1` | **PASS** |  |
| `docx_wording:P01-CLM-007/v1` | **PASS** |  |
| `docx_claim:P01-CLM-008/v1` | **PASS** |  |
| `docx_wording:P01-CLM-008/v1` | **PASS** |  |
| `docx_claim:P01-CLM-009/v1` | **PASS** |  |
| `docx_wording:P01-CLM-009/v1` | **PASS** |  |
| `docx_claim:P01-CLM-010/v1` | **PASS** |  |
| `docx_wording:P01-CLM-010/v1` | **PASS** |  |
| `docx_claim:P01-CLM-011/v1` | **PASS** |  |
| `docx_wording:P01-CLM-011/v1` | **PASS** |  |
| `docx_claim:P01-CLM-012/v1` | **PASS** |  |
| `docx_wording:P01-CLM-012/v1` | **PASS** |  |
| `docx_no_TODO` | **PASS** |  |
| `docx_no_TBD` | **PASS** |  |
| `docx_no_FIXME` | **PASS** |  |
| `docx_no_transient_path` | **PASS** |  |
| `docx_a11y_zero` | **PASS** | {'high': 0, 'medium': 0, 'low': 0} |
| `p01_bundle_crc` | **PASS** |  |
| `p01_bundle_member_count` | **PASS** | 13216 |
| `p01_bundle_sha256` | **PASS** | 09c3bb0442d79ddf110cf66fc4fe61fe63e94c7d8ed9f198f606639b4191f16e |
| `p01_checksum_row_count` | **PASS** | 13164 |
| `p01_checksum_integrity` | **PASS** | {'good': 13164, 'bad': 0} |
| `docx_render_page_count` | **PASS** | 42 |
| `docx_no_blank_pages` | **PASS** | [] |
| `p00_mapping_loss_zero` | **PASS** |  |
| `p01_mapping_loss_zero` | **PASS** |  |
| `reviewed_wording_drift_zero` | **PASS** |  |
| `mandatory_limitation_drift_zero` | **PASS** |  |
| `broken_foreign_keys_zero` | **PASS** |  |
| `supported_claims_without_valid_evidence_route_zero` | **PASS** |  |
| `layer10_source_ready` | **PASS** |  |
| `no_scientific_result_change` | **PASS** |  |
| `protocol_unchanged` | **PASS** |  |

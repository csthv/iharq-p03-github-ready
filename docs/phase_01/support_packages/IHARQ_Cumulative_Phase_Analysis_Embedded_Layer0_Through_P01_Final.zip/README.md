# IHARQ cumulative Phase Analysis + embedded Layer 0 through P01

**Canonical authority:** `IHARQ_Cumulative_Phase_Evidence_Results_and_Interpretation_Report_Through_P01_Current.md`

The current owner-directed architecture integrates Layer 0 directly into the cumulative Phase Analysis. Phase Analysis findings remain immutable analytical content; Layer 0 claim wording/disposition is embedded in separate clearly labelled parts.

The `phase_01_layer0_derivative/` folder is supplied separately at owner request. It is **non-authoritative** and exists for convenient P01-only Layer 0 review; the canonical cumulative Markdown controls if any drift is detected.

Structured YAML/JSON/CSV files are non-authoritative derivatives.
